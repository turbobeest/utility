/* global React, I, cx, Kbd, IconBtn, Btn, Badge, Dropdown, MenuItem, MenuDivider, SparkMark */
const { useState, useEffect, useRef, useMemo, Fragment } = React;

/* ───────────────────────────────────────────────────────────────
   TOP NAV BAR
   ─────────────────────────────────────────────────────────────── */
function TopNavBar({ dark, onToggleTheme, onToggleSRML, onOpenCommand, onOpenHelp, srmlOpen }) {
  return (
    <header className={cx(
      "h-12 flex items-center justify-between px-4 select-none",
      "bg-slate-950/90 border-b border-slate-800 backdrop-blur",
      "[html:not(.dark)_&]:bg-white/95 [html:not(.dark)_&]:border-slate-200"
    )}>
      <div className="flex items-center gap-2.5">
        <SparkMark size={22}/>
        <div className="flex items-baseline gap-1.5">
          <span className="text-[14px] font-semibold tracking-tight text-white [html:not(.dark)_&]:text-slate-900">
            SpARK
          </span>
          <span className="text-[14px] font-medium tracking-[0.04em] text-slate-300 [html:not(.dark)_&]:text-slate-600">
            DIAGRAMJAM
          </span>
          <span className="ml-2 text-[10.5px] font-mono px-1.5 h-[18px] inline-flex items-center rounded
            bg-slate-800 text-slate-400 border border-slate-700
            [html:not(.dark)_&]:bg-slate-100 [html:not(.dark)_&]:text-slate-500 [html:not(.dark)_&]:border-slate-200">
            v2.0
          </span>
        </div>
        <div className="hidden md:flex items-center ml-4 gap-1.5 text-[12px] text-slate-400 [html:not(.dark)_&]:text-slate-500">
          <span className="text-slate-600 [html:not(.dark)_&]:text-slate-400">/</span>
          <span>order-platform</span>
          <span className="text-slate-600 [html:not(.dark)_&]:text-slate-400">/</span>
          <span className="text-slate-200 [html:not(.dark)_&]:text-slate-800 font-medium">edge-architecture.srml</span>
          <Badge variant="success" className="ml-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"/>
            saved
          </Badge>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden lg:flex items-center -space-x-1.5 mr-1">
          {[
            { c: "bg-blue-500", t: "AT" },
            { c: "bg-amber-500", t: "MN" },
            { c: "bg-emerald-500", t: "RS" },
          ].map((u, i) => (
            <div key={i} className={cx(
              "w-6 h-6 rounded-full text-[10px] font-semibold text-white inline-flex items-center justify-center",
              "ring-2 ring-slate-950 [html:not(.dark)_&]:ring-white", u.c
            )} title={u.t}>{u.t}</div>
          ))}
        </div>
        <IconBtn icon={I.Help} title="Help" onClick={onOpenHelp}/>
        <button
          onClick={onToggleTheme}
          title="Toggle theme"
          className="h-8 w-8 inline-flex items-center justify-center rounded-md text-slate-300 hover:text-white hover:bg-white/5 [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:bg-slate-100"
        >
          {dark ? <I.Sun size={16}/> : <I.Moon size={16}/>}
        </button>
        <button
          onClick={onToggleSRML}
          title="Toggle SRML Inspector (⌘I)"
          className={cx(
            "h-8 inline-flex items-center gap-1.5 px-2 rounded-md text-[12.5px] font-medium transition-colors",
            srmlOpen
              ? "bg-blue-600/15 text-blue-300 border border-blue-500/30"
              : "text-slate-300 hover:text-white hover:bg-white/5 border border-transparent [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:bg-slate-100"
          )}
        >
          <I.Panel size={14}/>
          SRML
        </button>
        <button
          onClick={onOpenCommand}
          title="Command palette (⌘K)"
          className="h-8 inline-flex items-center gap-2 pl-2 pr-1 rounded-md text-[12.5px]
            text-slate-300 hover:text-white hover:bg-white/5 border border-slate-800
            [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:bg-slate-100 [html:not(.dark)_&]:border-slate-200"
        >
          <I.Search size={13}/>
          <span className="hidden sm:inline">Search…</span>
          <Kbd className="ml-1">⌘K</Kbd>
        </button>
      </div>
    </header>
  );
}

/* ───────────────────────────────────────────────────────────────
   CENTERED TOOLBAR — actions row + drawing tools row, all centered
   ─────────────────────────────────────────────────────────────── */
const TOOLS = [
  { id: "select",  icon: I.Cursor,  label: "Selection",  shortcut: "V" },
  { id: "hand",    icon: I.Hand,    label: "Hand / Pan", shortcut: "H" },
  { id: "rect",    icon: I.Rect,    label: "Rectangle",  shortcut: "R" },
  { id: "ellipse", icon: I.Ellipse, label: "Ellipse",    shortcut: "O" },
  { id: "diamond", icon: I.Diamond, label: "Diamond",    shortcut: "D" },
  { id: "arrow",   icon: I.Arrow,   label: "Arrow",      shortcut: "A" },
  { id: "line",    icon: I.Line,    label: "Line",       shortcut: "L" },
  { id: "draw",    icon: I.Pencil,  label: "Freedraw",   shortcut: "P" },
  { id: "text",    icon: I.Text,    label: "Text",       shortcut: "T" },
  { id: "image",   icon: I.Image,   label: "Image",      shortcut: "I" },
  { id: "link",    icon: I.Link,    label: "Link",       shortcut: "K" },
];

function CenteredToolbar({ tool, setTool, onImport, onExport, onStandard, onValidate, onAskAI, onChooseStandard, currentStandard }) {
  return (
    <div className={cx(
      "relative border-b flex flex-col items-center gap-2 py-2.5",
      "bg-slate-900/70 border-slate-800 backdrop-blur",
      "[html:not(.dark)_&]:bg-slate-50/95 [html:not(.dark)_&]:border-slate-200"
    )}>
      {/* Row 1 — actions */}
      <div className="flex items-center gap-1">
        <Dropdown trigger={<span>Import</span>}>
          <MenuItem icon={I.FolderIn}    onClick={() => onImport("DOT")}    shortcut="⌘O">Import .dot (Graphviz)</MenuItem>
          <MenuItem icon={I.FileText}    onClick={() => onImport("Visio")}>Import .vsdx (Visio)</MenuItem>
          <MenuItem icon={I.Code}        onClick={() => onImport("Codebase")}>Scan codebase…</MenuItem>
          <MenuItem icon={I.Picture}     onClick={() => onImport("Image")}>From image (AI trace)</MenuItem>
          <MenuDivider/>
          <MenuItem icon={I.FileText}    onClick={() => onImport("SRML")}>Open .srml file</MenuItem>
        </Dropdown>

        <Dropdown trigger={<span>Export</span>}>
          <MenuItem icon={I.FileText}  onClick={() => onExport("DOT")}     shortcut="⌘E">Export as .dot</MenuItem>
          <MenuItem icon={I.Vector}    onClick={() => onExport("SVG")}>Export as SVG</MenuItem>
          <MenuItem icon={I.Picture}   onClick={() => onExport("PNG")}>Export as PNG (2×)</MenuItem>
          <MenuDivider/>
          <MenuItem icon={I.Download}  onClick={() => onExport("SRML")}>Download .srml bundle</MenuItem>
        </Dropdown>

        <Dropdown trigger={<span>Standards{currentStandard ? `: ${currentStandard}` : ""}</span>} width={240}>
          <MenuItem onClick={() => onChooseStandard("C4 Model")}>C4 Model — context/container/code</MenuItem>
          <MenuItem onClick={() => onChooseStandard("UML Class")}>UML Class</MenuItem>
          <MenuItem onClick={() => onChooseStandard("SysML IBD")}>SysML IBD</MenuItem>
          <MenuItem onClick={() => onChooseStandard("UAF SV-1")}>UAF SV-1</MenuItem>
          <MenuDivider/>
          <MenuItem onClick={() => onChooseStandard(null)}>None / free-form</MenuItem>
        </Dropdown>

        <div className="mx-1 h-5 w-px bg-slate-800 [html:not(.dark)_&]:bg-slate-200"/>

        <Btn variant="outline" icon={I.Check} onClick={onValidate}>Validate</Btn>
        <Btn variant="primary" icon={I.Sparkles} onClick={onAskAI} className="ai-pulse">Claude Code</Btn>
      </div>

      {/* Row 2 — drawing tools */}
      <div className={cx(
        "flex items-center gap-0.5 p-1 rounded-xl border",
        "bg-slate-950/70 border-slate-800",
        "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:shadow-sm"
      )}>
        {TOOLS.flatMap((t, i) => {
          const btn = (
            <button
              key={t.id}
              onClick={() => setTool(t.id)}
              title={`${t.label} — ${t.shortcut}`}
              className={cx(
                "relative h-9 w-9 inline-flex items-center justify-center rounded-md transition-all",
                tool === t.id
                  ? "bg-blue-600 text-white shadow-md shadow-blue-900/40"
                  : "text-slate-300 hover:text-white hover:bg-white/5 [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:text-slate-900 [html:not(.dark)_&]:hover:bg-slate-100"
              )}
            >
              <t.icon size={17}/>
              <span className={cx(
                "absolute bottom-0.5 right-0.5 text-[9px] font-mono leading-none",
                tool === t.id ? "text-blue-200" : "text-slate-500"
              )}>{t.shortcut}</span>
            </button>
          );
          if (i === 2) {
            return [
              <div key={`${t.id}-sep`} className="mx-1 h-5 w-px bg-slate-800 [html:not(.dark)_&]:bg-slate-200"/>,
              btn,
            ];
          }
          return [btn];
        })}
      </div>
    </div>
  );
}

/* ───────────────────────────────────────────────────────────────
   COMMAND PALETTE
   ─────────────────────────────────────────────────────────────── */
function CommandPalette({ open, onClose, commands, onRun }) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setIdx(0);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  const filtered = useMemo(() => {
    const s = q.toLowerCase().trim();
    if (!s) return commands;
    return commands.filter(c => (c.label + " " + (c.group||"") + " " + (c.shortcut||"")).toLowerCase().includes(s));
  }, [q, commands]);

  useEffect(() => { setIdx(0); }, [q]);

  if (!open) return null;

  const onKeyDown = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setIdx(i => Math.min(filtered.length - 1, i + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setIdx(i => Math.max(0, i - 1)); }
    else if (e.key === "Enter") { e.preventDefault(); const c = filtered[idx]; if (c) { onRun(c); onClose(); } }
    else if (e.key === "Escape") { e.preventDefault(); onClose(); }
  };

  // Group filtered by group label, preserving order
  const groups = [];
  const seen = new Map();
  filtered.forEach((c, i) => {
    const g = c.group || "Other";
    if (!seen.has(g)) { seen.set(g, groups.length); groups.push({ name: g, items: [] }); }
    groups[seen.get(g)].items.push({ ...c, _i: i });
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[14vh]" onClick={onClose}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-sm"/>
      <div
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
        className={cx(
          "relative w-[640px] max-w-[92vw] rounded-xl overflow-hidden shadow-2xl shadow-black/60",
          "bg-slate-900/95 border border-slate-700/80 backdrop-blur",
          "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200"
        )}
      >
        <div className="flex items-center gap-2.5 px-3.5 h-12 border-b border-slate-800 [html:not(.dark)_&]:border-slate-200">
          <I.Search size={16} className="text-slate-400"/>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search commands, files, requirements…"
            className="flex-1 bg-transparent outline-none text-[14px] text-slate-100 placeholder:text-slate-500
              [html:not(.dark)_&]:text-slate-900 [html:not(.dark)_&]:placeholder:text-slate-400"
          />
          <Kbd>esc</Kbd>
        </div>
        <div className="max-h-[55vh] overflow-y-auto py-2">
          {filtered.length === 0 ? (
            <div className="px-4 py-10 text-center text-[13px] text-slate-400">
              No matches for <span className="text-slate-200">"{q}"</span>
            </div>
          ) : groups.map(g => (
            <div key={g.name} className="px-2">
              <div className="px-2 py-1.5 text-[10.5px] font-semibold tracking-wider uppercase text-slate-500 [html:not(.dark)_&]:text-slate-400">
                {g.name}
              </div>
              {g.items.map(c => (
                <button
                  key={c.id}
                  onMouseEnter={() => setIdx(c._i)}
                  onClick={() => { onRun(c); onClose(); }}
                  className={cx(
                    "w-full flex items-center gap-2.5 px-2.5 h-9 rounded-md text-left text-[13px] transition-colors",
                    c._i === idx
                      ? "bg-blue-600/15 text-white [html:not(.dark)_&]:bg-blue-50 [html:not(.dark)_&]:text-slate-900"
                      : "text-slate-200 [html:not(.dark)_&]:text-slate-700"
                  )}
                >
                  {c.icon ? <c.icon size={15} className="text-slate-400"/> : <span className="w-[15px]"/>}
                  <span className="flex-1">{c.label}</span>
                  {c.hint && <span className="text-[11.5px] text-slate-500">{c.hint}</span>}
                  {c.shortcut && <Kbd>{c.shortcut}</Kbd>}
                </button>
              ))}
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between px-3.5 h-9 border-t border-slate-800 text-[11px] text-slate-500
          [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:text-slate-500">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><Kbd>↑</Kbd><Kbd>↓</Kbd> navigate</span>
            <span className="flex items-center gap-1"><Kbd>↵</Kbd> select</span>
            <span className="flex items-center gap-1"><Kbd>esc</Kbd> close</span>
          </div>
          <span>{filtered.length} result{filtered.length === 1 ? "" : "s"}</span>
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────────────────────────────────────────────
   TOAST STACK
   ─────────────────────────────────────────────────────────────── */
function ToastStack({ toasts, dismiss }) {
  return (
    <div className="fixed top-3 right-3 z-40 flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => {
        const Ic = t.variant === "success" ? I.Check : t.variant === "warning" ? I.Warn : t.variant === "error" ? I.X : I.Info;
        const color = {
          success: "text-emerald-400 border-emerald-500/40",
          warning: "text-amber-400 border-amber-500/40",
          error:   "text-rose-400 border-rose-500/40",
          info:    "text-blue-400 border-blue-500/40",
        }[t.variant || "info"];
        return (
          <div key={t.id} className={cx(
            "toast-in pointer-events-auto w-[320px] rounded-lg border shadow-2xl shadow-black/40 overflow-hidden",
            "bg-slate-900/95 backdrop-blur",
            "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:shadow-slate-300/50",
            color
          )}>
            <div className="flex gap-2.5 p-3">
              <Ic size={18} className={color}/>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-semibold text-slate-100 [html:not(.dark)_&]:text-slate-900">{t.title}</div>
                {t.body && <div className="mt-0.5 text-[12px] text-slate-300 [html:not(.dark)_&]:text-slate-600">{t.body}</div>}
              </div>
              <button onClick={() => dismiss(t.id)} className="text-slate-500 hover:text-slate-200 [html:not(.dark)_&]:hover:text-slate-900">
                <I.X size={14}/>
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { TopNavBar, CenteredToolbar, CommandPalette, ToastStack, TOOLS });
