/* global React, I, cx, Btn, Badge, IconBtn, Kbd, NODES, EDGES, elementFor */
const { useState, useEffect, useMemo, useRef } = React;

/* ───────────────────────────────────────────────────────────────
   CANVAS — mock embedded Excalidraw-style diagram surface
   The real product embeds the Excalidraw library; we render a
   representative diagram so the surrounding chrome has live
   selection / hover state to react to.
   ─────────────────────────────────────────────────────────────── */

const NODE_FILLS = {
  external:  { fill: "#1e293b", stroke: "#475569", text: "#e2e8f0", badge: "#94a3b8" },
  component: { fill: "#1e3a8a", stroke: "#3b82f6", text: "#dbeafe", badge: "#93c5fd" },
  service:   { fill: "#172554", stroke: "#3b82f6", text: "#dbeafe", badge: "#93c5fd" },
  infra:     { fill: "#422006", stroke: "#f59e0b", text: "#fde68a", badge: "#fcd34d" },
  datastore: { fill: "#1e293b", stroke: "#64748b", text: "#e2e8f0", badge: "#94a3b8" },
};
const NODE_FILLS_LIGHT = {
  external:  { fill: "#ffffff", stroke: "#cbd5e1", text: "#1e293b", badge: "#64748b" },
  component: { fill: "#eff6ff", stroke: "#3b82f6", text: "#1e3a8a", badge: "#2563eb" },
  service:   { fill: "#eff6ff", stroke: "#3b82f6", text: "#1e3a8a", badge: "#2563eb" },
  infra:     { fill: "#fffbeb", stroke: "#f59e0b", text: "#92400e", badge: "#b45309" },
  datastore: { fill: "#f8fafc", stroke: "#94a3b8", text: "#1e293b", badge: "#64748b" },
};

function NodeShape({ node, selected, hovered, onClick, onHover, palette }) {
  const p = palette[node.kind] || palette.component;
  const cx_ = node.x + node.w / 2;
  const cy_ = node.y + node.h / 2;
  const stroke = selected ? "#60a5fa" : (hovered ? "#7dd3fc" : p.stroke);
  const sw = selected ? 2.2 : 1.4;

  let shapeEl;
  if (node.shape === "ellipse") {
    shapeEl = <ellipse cx={cx_} cy={cy_} rx={node.w/2} ry={node.h/2} fill={p.fill} stroke={stroke} strokeWidth={sw}/>;
  } else if (node.shape === "diamond") {
    const pts = `${cx_},${node.y} ${node.x + node.w},${cy_} ${cx_},${node.y + node.h} ${node.x},${cy_}`;
    shapeEl = <polygon points={pts} fill={p.fill} stroke={stroke} strokeWidth={sw}/>;
  } else {
    shapeEl = <rect x={node.x} y={node.y} width={node.w} height={node.h} rx={9} ry={9} fill={p.fill} stroke={stroke} strokeWidth={sw}/>;
  }

  return (
    <g
      className="cursor-pointer"
      onMouseEnter={() => onHover(node.id)}
      onMouseLeave={() => onHover(null)}
      onClick={(e) => { e.stopPropagation(); onClick(node.id); }}
    >
      {/* Selection halo */}
      {selected && (
        node.shape === "ellipse"
          ? <ellipse cx={cx_} cy={cy_} rx={node.w/2 + 7} ry={node.h/2 + 7} fill="none" stroke="#60a5fa" strokeWidth="1.2" className="marching" opacity="0.85"/>
          : node.shape === "diamond"
            ? <polygon points={`${cx_},${node.y - 9} ${node.x + node.w + 9},${cy_} ${cx_},${node.y + node.h + 9} ${node.x - 9},${cy_}`} fill="none" stroke="#60a5fa" strokeWidth="1.2" className="marching" opacity="0.85"/>
            : <rect x={node.x - 7} y={node.y - 7} width={node.w + 14} height={node.h + 14} rx={13} fill="none" stroke="#60a5fa" strokeWidth="1.2" className="marching" opacity="0.85"/>
      )}
      {shapeEl}

      {/* Warning corner */}
      {node.warn && (
        <g transform={`translate(${node.x + node.w - 16}, ${node.y + 6})`}>
          <circle cx="5" cy="5" r="6" fill="#f59e0b"/>
          <text x="5" y="8.5" fill="#1e293b" fontSize="9" fontWeight="700" textAnchor="middle">!</text>
        </g>
      )}

      <text x={cx_} y={cy_ - 2} fill={p.text} fontSize="13" fontWeight="600" textAnchor="middle" dominantBaseline="middle" style={{ pointerEvents: "none" }}>
        {node.label}
      </text>
      {node.badge && (
        <text x={cx_} y={cy_ + 14} fill={p.badge} fontSize="10" fontWeight="500" textAnchor="middle" style={{ pointerEvents: "none" }}>
          {node.badge}
        </text>
      )}
      {!node.badge && (
        <text x={cx_} y={cy_ + 14} fill={p.badge} fontSize="10" fontWeight="500" textAnchor="middle" style={{ pointerEvents: "none", opacity: 0.7 }}>
          {node.kind}
        </text>
      )}
    </g>
  );
}

function edgeAnchor(n, towardX, towardY) {
  // anchor on rectangle border (close-enough for ellipse/diamond too at this fidelity)
  const cxN = n.x + n.w / 2;
  const cyN = n.y + n.h / 2;
  const dx = towardX - cxN;
  const dy = towardY - cyN;
  const hw = n.w / 2;
  const hh = n.h / 2;
  if (dx === 0 && dy === 0) return [cxN, cyN];
  const ax = Math.abs(dx);
  const ay = Math.abs(dy);
  const sx = dx === 0 ? 0 : dx / ax;
  const sy = dy === 0 ? 0 : dy / ay;
  if (ax / hw > ay / hh) {
    return [cxN + sx * hw, cyN + sy * (hw * ay / ax || 0)];
  }
  return [cxN + sx * (hh * ax / ay || 0), cyN + sy * hh];
}

function Canvas({ selectedId, setSelectedId, dark, zoom, tool }) {
  const [hover, setHover] = useState(null);
  const palette = dark ? NODE_FILLS : NODE_FILLS_LIGHT;
  const nodesById = useMemo(() => Object.fromEntries(NODES.map(n => [n.id, n])), []);
  const containerRef = useRef(null);

  // Render edges
  const edgeEls = EDGES.map((e, i) => {
    const a = nodesById[e.from]; const b = nodesById[e.to];
    if (!a || !b) return null;
    const acx = a.x + a.w/2; const acy = a.y + a.h/2;
    const bcx = b.x + b.w/2; const bcy = b.y + b.h/2;
    const [ax, ay] = edgeAnchor(a, bcx, bcy);
    const [bx, by] = edgeAnchor(b, acx, acy);
    const mx = (ax + bx) / 2;
    const my = (ay + by) / 2 - 8;
    const isIncidentToSel = selectedId && (e.from === selectedId || e.to === selectedId);
    const stroke = isIncidentToSel ? "#60a5fa" : (dark ? "#475569" : "#94a3b8");
    const sw = isIncidentToSel ? 2 : 1.4;
    return (
      <g key={i}>
        <path d={`M ${ax} ${ay} Q ${mx} ${my - 18} ${bx} ${by}`} fill="none" stroke={stroke} strokeWidth={sw} markerEnd="url(#arrow)" opacity={selectedId && !isIncidentToSel ? 0.45 : 1}/>
        {e.label && (
          <g>
            <rect x={mx - (e.label.length * 3.4) - 5} y={my - 28} width={e.label.length * 6.8 + 10} height={16} rx={3}
                  fill={dark ? "#0b1220" : "#ffffff"} stroke={isIncidentToSel ? "#60a5fa" : (dark ? "#334155" : "#e2e8f0")} strokeWidth="1"/>
            <text x={mx} y={my - 17} fill={dark ? "#cbd5e1" : "#475569"} fontSize="10" textAnchor="middle" fontWeight="500">{e.label}</text>
          </g>
        )}
      </g>
    );
  });

  // boundary groups
  const boundaries = [
    { id: "edge",     label: "Edge / DMZ",       x: 22,  y: 130, w: 220, h: 320, stroke: "#7c3aed", dashOffset: 0 },
    { id: "internal", label: "Internal VPC",     x: 262, y: 130, w: 700, h: 360, stroke: "#3b82f6", dashOffset: 0 },
    { id: "data",     label: "Data Plane",       x: 952, y: 170, w: 220, h: 280, stroke: "#10b981", dashOffset: 0 },
  ];

  const cursor = tool === "hand" ? "cursor-grab"
                 : tool === "select" ? "cursor-default"
                 : "cursor-crosshair";

  return (
    <div ref={containerRef}
         className={cx("relative flex-1 overflow-hidden", dark ? "canvas-grid-dark" : "canvas-grid-light", cursor)}
         onClick={() => setSelectedId(null)}
    >
      <svg viewBox="0 0 1200 600" className="absolute inset-0 w-full h-full" preserveAspectRatio="xMidYMid meet" style={{ transform: `scale(${zoom})`, transformOrigin: "center center" }}>
        <defs>
          <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#60a5fa"/>
          </marker>
        </defs>

        {/* Boundaries */}
        {boundaries.map(b => (
          <g key={b.id}>
            <rect x={b.x} y={b.y} width={b.w} height={b.h} rx={14} fill="none"
                  stroke={b.stroke} strokeWidth="1.2" strokeDasharray="5 5" opacity="0.55"/>
            <text x={b.x + 12} y={b.y + 18} fill={b.stroke} fontSize="11" fontWeight="600" letterSpacing="0.04em">
              {b.label.toUpperCase()}
            </text>
          </g>
        ))}

        {edgeEls}

        {NODES.map(n => (
          <NodeShape
            key={n.id}
            node={n}
            selected={selectedId === n.id}
            hovered={hover === n.id}
            onClick={setSelectedId}
            onHover={setHover}
            palette={palette}
          />
        ))}
      </svg>

      {/* Floating zoom hud */}
      <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-slate-900/85 backdrop-blur border border-slate-700/80 rounded-lg px-1 py-1 shadow-lg
        [html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:shadow-sm">
        <IconBtn title="Zoom out">
          <span className="text-slate-300 text-base [html:not(.dark)_&]:text-slate-600">−</span>
        </IconBtn>
        <div className="text-[11px] font-mono w-[44px] text-center text-slate-300 [html:not(.dark)_&]:text-slate-600">
          {Math.round(zoom * 100)}%
        </div>
        <IconBtn title="Zoom in">
          <span className="text-slate-300 text-base [html:not(.dark)_&]:text-slate-600">+</span>
        </IconBtn>
        <div className="w-px h-5 bg-slate-700/80 mx-0.5 [html:not(.dark)_&]:bg-slate-200"/>
        <button className="h-8 px-2 text-[11px] font-mono text-slate-300 rounded hover:bg-white/5 [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:bg-slate-100">
          Fit
        </button>
      </div>

      {/* Minimap */}
      <div className="absolute bottom-3 right-3 w-[180px] h-[110px] rounded-lg overflow-hidden border border-slate-700/80 bg-slate-900/85 backdrop-blur shadow-lg
        [html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200">
        <svg viewBox="0 0 1200 600" className="w-full h-full">
          {NODES.map(n => (
            <rect key={n.id} x={n.x} y={n.y} width={n.w} height={n.h} rx={6}
                  fill={selectedId === n.id ? "#3b82f6" : (dark ? "#475569" : "#cbd5e1")}/>
          ))}
          <rect x="80" y="60" width="900" height="470" fill="none" stroke="#3b82f6" strokeWidth="6"/>
        </svg>
      </div>

      {/* Selection helper */}
      {!selectedId && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 text-[11.5px] text-slate-400 bg-slate-900/85 backdrop-blur border border-slate-700/80 rounded-full px-3 py-1.5 shadow
          [html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:text-slate-500">
          Click any element to inspect its SRML metadata
        </div>
      )}
    </div>
  );
}

/* ───────────────────────────────────────────────────────────────
   SRML INSPECTOR — right panel with 5 tabs
   ─────────────────────────────────────────────────────────────── */
const SRML_TABS = [
  { id: "identity", label: "Identity" },
  { id: "specs",    label: "Specs" },
  { id: "reqs",     label: "Requirements" },
  { id: "qa",       label: "Quality" },
  { id: "trace",    label: "Trace" },
];

function FormGroup({ label, hint, children }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between">
        <label className="text-[11px] font-semibold tracking-wider uppercase text-slate-400 [html:not(.dark)_&]:text-slate-500">{label}</label>
        {hint && <span className="text-[10.5px] text-slate-500">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

const inpClass = "w-full h-9 px-2.5 rounded-md text-[13px] outline-none transition-colors " +
  "bg-slate-950/60 border border-slate-700 text-slate-100 placeholder:text-slate-500 " +
  "focus:border-blue-500 focus:bg-slate-900 " +
  "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-300 [html:not(.dark)_&]:text-slate-900 [html:not(.dark)_&]:focus:border-blue-500";

function SRMLPanel({ open, onClose, selectedId, onValidationToast }) {
  const [tab, setTab] = useState("identity");
  const el = selectedId ? elementFor(selectedId) : null;
  const [dirty, setDirty] = useState(false);
  const [draft, setDraft] = useState(null);

  useEffect(() => {
    if (el) { setDraft({ name: el.name, type: el.type, domain: el.domain, owner: el.owner, description: el.description }); setDirty(false); }
    else setDraft(null);
  }, [selectedId]);

  if (!open) return null;

  if (!selectedId || !el) {
    return (
      <aside className={cx(
        "w-[360px] flex-shrink-0 border-l flex flex-col",
        "bg-slate-900/80 border-slate-800",
        "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200"
      )}>
        <div className="h-12 px-4 flex items-center justify-between border-b border-slate-800 [html:not(.dark)_&]:border-slate-200">
          <div className="flex items-center gap-2">
            <I.Panel size={15} className="text-blue-400"/>
            <h2 className="text-[13px] font-semibold text-slate-100 [html:not(.dark)_&]:text-slate-900">SRML Inspector</h2>
          </div>
          <IconBtn icon={I.X} title="Close" onClick={onClose}/>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-center
            [html:not(.dark)_&]:bg-slate-100 [html:not(.dark)_&]:border-slate-200">
            <I.Cursor size={22} className="text-slate-400"/>
          </div>
          <div>
            <div className="text-[13px] font-semibold text-slate-200 [html:not(.dark)_&]:text-slate-900">No selection</div>
            <div className="mt-1 text-[12px] text-slate-400 leading-relaxed [html:not(.dark)_&]:text-slate-500">
              Pick an element on the canvas to view and edit its specification, requirements, and traceability links.
            </div>
          </div>
        </div>
      </aside>
    );
  }

  const TabBtn = ({ t }) => (
    <button
      onClick={() => setTab(t.id)}
      className={cx(
        "px-2.5 h-9 text-[12px] font-medium relative transition-colors",
        tab === t.id
          ? "text-white [html:not(.dark)_&]:text-slate-900"
          : "text-slate-400 hover:text-slate-200 [html:not(.dark)_&]:text-slate-500 [html:not(.dark)_&]:hover:text-slate-900"
      )}
    >
      {t.label}
      {tab === t.id && <span className="absolute left-2 right-2 -bottom-px h-[2px] bg-blue-500 rounded-full"/>}
    </button>
  );

  return (
    <aside className={cx(
      "w-[360px] flex-shrink-0 border-l flex flex-col min-h-0",
      "bg-slate-900/80 border-slate-800",
      "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200"
    )}>
      {/* Header */}
      <div className="h-12 px-4 flex items-center justify-between border-b border-slate-800 [html:not(.dark)_&]:border-slate-200 flex-shrink-0">
        <div className="flex items-center gap-2">
          <I.Panel size={15} className="text-blue-400"/>
          <h2 className="text-[13px] font-semibold text-slate-100 [html:not(.dark)_&]:text-slate-900">SRML Inspector</h2>
          <Badge variant="info" className="!h-[18px] !px-1.5 !text-[10px]">{el.type}</Badge>
        </div>
        <IconBtn icon={I.X} title="Close" onClick={onClose}/>
      </div>

      {/* Element identity bar */}
      <div className="px-4 py-3 border-b border-slate-800 [html:not(.dark)_&]:border-slate-200 flex-shrink-0">
        <div className="text-[10.5px] font-mono text-slate-500">{el.id}</div>
        <div className="text-[15px] font-semibold text-slate-100 [html:not(.dark)_&]:text-slate-900">{el.name}</div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 px-3 border-b border-slate-800 [html:not(.dark)_&]:border-slate-200 overflow-x-auto no-scrollbar flex-shrink-0">
        {SRML_TABS.map(t => <TabBtn key={t.id} t={t}/>)}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 min-h-0">
        {tab === "identity" && (
          <>
            <FormGroup label="Element ID" hint="immutable">
              <input value={el.id} readOnly className={cx(inpClass, "font-mono text-slate-400 cursor-not-allowed")}/>
            </FormGroup>
            <FormGroup label="Display name">
              <input value={draft?.name || ""} onChange={(e) => { setDraft(d => ({ ...d, name: e.target.value })); setDirty(true); }} className={inpClass}/>
            </FormGroup>
            <div className="grid grid-cols-2 gap-3">
              <FormGroup label="Type">
                <select value={draft?.type || el.type} onChange={(e) => { setDraft(d => ({ ...d, type: e.target.value })); setDirty(true); }} className={inpClass}>
                  <option>Component</option><option>System</option><option>Operation</option>
                  <option>Service</option><option>Datastore</option><option>Infra</option><option>External</option>
                </select>
              </FormGroup>
              <FormGroup label="Domain">
                <input value={draft?.domain || ""} onChange={(e) => { setDraft(d => ({ ...d, domain: e.target.value })); setDirty(true); }} className={inpClass}/>
              </FormGroup>
            </div>
            <FormGroup label="Owner">
              <input value={draft?.owner || ""} onChange={(e) => { setDraft(d => ({ ...d, owner: e.target.value })); setDirty(true); }} className={inpClass}/>
            </FormGroup>
            <FormGroup label="Description">
              <textarea rows={4} value={draft?.description || ""} onChange={(e) => { setDraft(d => ({ ...d, description: e.target.value })); setDirty(true); }}
                className={cx(inpClass, "h-auto py-2 leading-relaxed resize-none")}/>
            </FormGroup>
            <FormGroup label="Tags">
              <div className="flex flex-wrap gap-1.5">
                {["edge", "stateless", "tier-0", "platform"].map(t => (
                  <Badge key={t} variant="outline">{t}</Badge>
                ))}
                <button className="h-6 px-2 text-[11px] rounded-full border border-dashed border-slate-600 text-slate-400 hover:text-slate-200 hover:border-slate-500
                  [html:not(.dark)_&]:border-slate-300 [html:not(.dark)_&]:text-slate-500">
                  + add tag
                </button>
              </div>
            </FormGroup>
          </>
        )}

        {tab === "specs" && (
          <>
            <div className="space-y-2">
              {el.specs.map((s, i) => (
                <div key={i} className="rounded-lg border border-slate-800 [html:not(.dark)_&]:border-slate-200 overflow-hidden">
                  <div className="px-3 py-2 flex items-center justify-between">
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-slate-400 [html:not(.dark)_&]:text-slate-500">{s.k}</span>
                    <button className="text-slate-500 hover:text-slate-200">
                      <I.X size={12}/>
                    </button>
                  </div>
                  <div className="px-3 pb-2.5 text-[13px] text-slate-100 [html:not(.dark)_&]:text-slate-900 font-mono">{s.v}</div>
                </div>
              ))}
            </div>
            <button className="w-full h-9 rounded-md border border-dashed border-slate-700 text-slate-400 text-[12.5px] hover:text-slate-200 hover:border-slate-500
              [html:not(.dark)_&]:border-slate-300 [html:not(.dark)_&]:text-slate-500">
              + add specification
            </button>
            <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-3 flex gap-2.5">
              <I.Sparkles size={14} className="text-blue-400 flex-shrink-0 mt-0.5"/>
              <div className="text-[12px] leading-relaxed text-slate-200 [html:not(.dark)_&]:text-slate-700">
                AI noticed: this component lacks an explicit <span className="font-semibold">retry policy</span>. Want to add one based on the C4 template?
              </div>
            </div>
          </>
        )}

        {tab === "reqs" && (
          <>
            <div className="flex items-center justify-between">
              <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                Linked requirements · <span className="text-slate-200">{el.reqs.length}</span>
              </div>
              <button className="text-[11.5px] text-blue-400 hover:text-blue-300">Link existing…</button>
            </div>
            <div className="space-y-2">
              {el.reqs.length === 0 && (
                <div className="text-[12px] text-slate-500 py-6 text-center">No requirements linked yet.</div>
              )}
              {el.reqs.map(r => (
                <div key={r.id} className="rounded-lg border border-slate-800 p-3 [html:not(.dark)_&]:border-slate-200">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10.5px] font-mono text-slate-500">{r.id}</span>
                    <Badge variant={r.status === "satisfied" ? "success" : r.status === "partial" ? "warning" : "error"}>
                      {r.status === "satisfied" ? "✓ satisfied" : r.status === "partial" ? "◐ partial" : "✗ missing"}
                    </Badge>
                  </div>
                  <div className="mt-1.5 text-[12.5px] text-slate-200 leading-relaxed [html:not(.dark)_&]:text-slate-700">{r.title}</div>
                </div>
              ))}
            </div>
          </>
        )}

        {tab === "qa" && (
          <>
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3 text-center">
                <div className="text-2xl font-semibold text-emerald-300">{el.qa.passing}</div>
                <div className="text-[10.5px] uppercase tracking-wider text-emerald-400/80 mt-0.5">passing</div>
              </div>
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-center">
                <div className="text-2xl font-semibold text-amber-300">{el.qa.warnings}</div>
                <div className="text-[10.5px] uppercase tracking-wider text-amber-400/80 mt-0.5">warnings</div>
              </div>
              <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-3 text-center">
                <div className="text-2xl font-semibold text-rose-300">{el.qa.errors}</div>
                <div className="text-[10.5px] uppercase tracking-wider text-rose-400/80 mt-0.5">errors</div>
              </div>
            </div>
            <div className="space-y-1.5">
              {el.qa.checks.map((c, i) => (
                <div key={i} className="flex items-start gap-2.5 py-1.5">
                  {c.ok
                    ? <I.Check size={14} className="text-emerald-400 mt-0.5 flex-shrink-0"/>
                    : <I.Warn  size={14} className="text-amber-400 mt-0.5 flex-shrink-0"/>}
                  <div className="flex-1">
                    <div className="text-[12.5px] text-slate-200 [html:not(.dark)_&]:text-slate-800">{c.t}</div>
                    {c.note && <div className="text-[11.5px] text-slate-400 mt-0.5 [html:not(.dark)_&]:text-slate-500">{c.note}</div>}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {tab === "trace" && (
          <>
            <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">Traceability matrix</div>
            <div className="rounded-lg border border-slate-800 overflow-hidden [html:not(.dark)_&]:border-slate-200">
              <div className="grid grid-cols-[1fr_auto_1fr] gap-2 px-3 py-2 text-[10.5px] uppercase tracking-wider font-semibold text-slate-500 border-b border-slate-800 [html:not(.dark)_&]:border-slate-200">
                <span>From</span><span></span><span>To</span>
              </div>
              {el.trace.length === 0 && <div className="text-[12px] text-slate-500 py-6 text-center">No trace links.</div>}
              {el.trace.map((t, i) => (
                <div key={i} className="grid grid-cols-[1fr_auto_1fr] gap-2 items-center px-3 py-2.5 border-b border-slate-800/70 last:border-b-0 [html:not(.dark)_&]:border-slate-100">
                  <span className="font-mono text-[11.5px] text-slate-200 truncate [html:not(.dark)_&]:text-slate-800">{t.from}</span>
                  <span className="flex items-center gap-1 text-[10px] text-slate-500">
                    <I.ChevronRight size={12}/>{t.via}
                  </span>
                  <span className="font-mono text-[11.5px] text-slate-200 truncate [html:not(.dark)_&]:text-slate-800">{t.to}</span>
                </div>
              ))}
            </div>
            <button className="w-full h-9 rounded-md border border-dashed border-slate-700 text-slate-400 text-[12.5px] hover:text-slate-200 hover:border-slate-500
              [html:not(.dark)_&]:border-slate-300 [html:not(.dark)_&]:text-slate-500">
              + add trace link
            </button>
          </>
        )}
      </div>

      {/* Footer */}
      <div className="h-14 px-4 flex items-center justify-between border-t border-slate-800 [html:not(.dark)_&]:border-slate-200 flex-shrink-0">
        {el.qa.errors === 0 && el.qa.warnings === 0
          ? <Badge variant="success"><I.Check size={11}/> Valid</Badge>
          : el.qa.errors > 0
            ? <Badge variant="error"><I.Warn size={11}/> {el.qa.errors} error{el.qa.errors === 1 ? "" : "s"}</Badge>
            : <Badge variant="warning"><I.Warn size={11}/> {el.qa.warnings} warning{el.qa.warnings === 1 ? "" : "s"}</Badge>
        }
        <div className="flex items-center gap-2">
          <Btn variant="ghost" onClick={() => { setDirty(false); onValidationToast?.("discarded"); }} disabled={!dirty}>Discard</Btn>
          <Btn variant="primary" onClick={() => { setDirty(false); onValidationToast?.("saved"); }} disabled={!dirty}>Save</Btn>
        </div>
      </div>
    </aside>
  );
}

/* ───────────────────────────────────────────────────────────────
   QUERY DRAWER — bottom sheet
   ─────────────────────────────────────────────────────────────── */
const EXAMPLE_PROMPTS = [
  { icon: "→", text: "Add retry policy to PaymentService", slash: false },
  { icon: "→", text: "Find unowned components",            slash: false },
  { icon: "→", text: "Validate edge contracts vs reqs",    slash: false },
  { icon: "/", text: "/scaffold ADR for queue change",     slash: true  },
  { icon: "/", text: "/refactor extract Event Bus",        slash: true  },
];

/* Seed conversation modeled after a real Claude Code session.
   `kind`:
     - "user"       — user prompt
     - "text"       — assistant prose
     - "tool"       — tool invocation card { name, args, summary, status, lines?, diff? }
*/
const SEED_LOG = [
  { kind: "user", text: "Why is PaymentService flagged as a warning? Fix it if it's fixable." },
  { kind: "text", text: "Looking at the SRML spec for PaymentService and any linked validation rules." },
  { kind: "tool", name: "Read",  args: "specs/payment-service.srml",          lines: 84,  status: "ok" },
  { kind: "tool", name: "Read",  args: "rules/c4.validation.yml",             lines: 142, status: "ok" },
  { kind: "tool", name: "Grep",  args: "\"retry\" specs/",                    lines: 3,   status: "ok",
    summary: "0 matches in payment-service.srml · 2 in order-service.srml" },
  { kind: "text", text: "PaymentService is missing a retry policy. Rule **edge.retry.required** demands one for any service that emits events. Adding it now using the same exponential-backoff pattern OrderService already uses." },
  { kind: "tool", name: "Edit",  args: "specs/payment-service.srml",          status: "ok", diff: { add: 12, del: 0 },
    preview: [
      { t: "add", s: "  retry:" },
      { t: "add", s: "    strategy: exponential" },
      { t: "add", s: "    base_ms: 200" },
      { t: "add", s: "    max_attempts: 3" },
      { t: "add", s: "    on: [timeout, 5xx]" },
    ],
  },
  { kind: "tool", name: "Bash",  args: "spark validate --rule c4.retry.required",  status: "ok",
    summary: "✓ payment-service · retry policy satisfies rule" },
  { kind: "text", text: "Fixed. PaymentService now has a 3-attempt exponential-backoff retry on timeouts and 5xx responses. The warning in the SRML inspector will clear on next validate." },
];

const TOOL_META = {
  Read:  { ic: I.FileText, tint: "text-sky-300",     bg: "bg-sky-500/10",     bd: "border-sky-500/30" },
  Edit:  { ic: I.Pencil,   tint: "text-emerald-300", bg: "bg-emerald-500/10", bd: "border-emerald-500/30" },
  Write: { ic: I.Pencil,   tint: "text-emerald-300", bg: "bg-emerald-500/10", bd: "border-emerald-500/30" },
  Grep:  { ic: I.Search,   tint: "text-violet-300",  bg: "bg-violet-500/10",  bd: "border-violet-500/30" },
  Bash:  { ic: I.Code,     tint: "text-amber-300",   bg: "bg-amber-500/10",   bd: "border-amber-500/30" },
  Glob:  { ic: I.FolderIn, tint: "text-sky-300",     bg: "bg-sky-500/10",     bd: "border-sky-500/30" },
};

function ToolCard({ entry }) {
  const meta = TOOL_META[entry.name] || TOOL_META.Read;
  const Ic = meta.ic;
  return (
    <div className={cx(
      "rounded-md border overflow-hidden",
      meta.bd, meta.bg,
      "[html:not(.dark)_&]:bg-white"
    )}>
      <div className="flex items-center gap-2 px-2.5 h-7">
        <Ic size={12} className={meta.tint}/>
        <span className={cx("font-mono text-[11.5px] font-semibold", meta.tint)}>{entry.name}</span>
        <span className="font-mono text-[11.5px] text-slate-300 truncate [html:not(.dark)_&]:text-slate-700">{entry.args}</span>
        <div className="flex-1"/>
        {entry.lines != null && (
          <span className="font-mono text-[10.5px] text-slate-400 [html:not(.dark)_&]:text-slate-500">{entry.lines} lines</span>
        )}
        {entry.diff && (
          <span className="font-mono text-[10.5px]">
            <span className="text-emerald-400">+{entry.diff.add}</span>{" "}
            <span className="text-rose-400">−{entry.diff.del}</span>
          </span>
        )}
        {entry.status === "ok" && <I.Check size={12} className="text-emerald-400"/>}
        {entry.status === "fail" && <I.Warn size={12} className="text-rose-400"/>}
        {entry.status === "running" && (
          <span className="flex gap-0.5">
            <span className="w-1 h-1 rounded-full bg-slate-400 animate-pulse"/>
            <span className="w-1 h-1 rounded-full bg-slate-400 animate-pulse" style={{animationDelay: "120ms"}}/>
            <span className="w-1 h-1 rounded-full bg-slate-400 animate-pulse" style={{animationDelay: "240ms"}}/>
          </span>
        )}
      </div>
      {(entry.summary || entry.preview) && (
        <div className="px-2.5 pb-2 pt-0.5 border-t border-white/5 [html:not(.dark)_&]:border-slate-100">
          {entry.summary && (
            <div className="font-mono text-[11px] text-slate-300 [html:not(.dark)_&]:text-slate-600 leading-relaxed">
              {entry.summary}
            </div>
          )}
          {entry.preview && (
            <pre className="font-mono text-[11px] leading-[1.5] mt-1 overflow-x-auto no-scrollbar">
              {entry.preview.map((p, i) => (
                <div key={i} className={cx(
                  "whitespace-pre",
                  p.t === "add" ? "text-emerald-300" : p.t === "del" ? "text-rose-300" : "text-slate-300"
                )}>
                  <span className="select-none opacity-60 mr-1">{p.t === "add" ? "+" : p.t === "del" ? "-" : " "}</span>
                  {p.s}
                </div>
              ))}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}

function QueryDrawer({ open, onToggle, focusOnNodes }) {
  const [log, setLog] = useState(SEED_LOG);
  const [val, setVal] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef(null);
  const [model] = useState("claude-sonnet-4-5");

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [log, busy]);

  const ask = (text) => {
    if (!text.trim()) return;
    setBusy(true);
    setLog(l => [...l, { kind: "user", text }]);
    setVal("");
    // Stage a fake tool sequence
    const steps = [
      { delay: 350, entry: { kind: "text", text: "I'll search the SRML graph for matching elements and explain what I find." } },
      { delay: 700, entry: { kind: "tool", name: "Grep",  args: `"${text.slice(0, 28)}" specs/`, status: "running" } },
      { delay: 1400, replace: { kind: "tool", name: "Grep", args: `"${text.slice(0, 28)}" specs/`, lines: 4, status: "ok", summary: "4 elements matched · highlighted on canvas" } },
      { delay: 1700, entry: { kind: "text", text: "Highlighted API Gateway, AuthService, OrderService, PaymentService on the canvas. Want me to draft a fix?" } },
      { delay: 1750, done: true },
    ];
    let acc = 0;
    steps.forEach(s => {
      acc += s.delay;
      setTimeout(() => {
        if (s.done) { setBusy(false); focusOnNodes?.(["api-gateway", "auth", "orders", "payments"]); return; }
        if (s.replace) setLog(l => { const next = [...l]; next[next.length - 1] = s.replace; return next; });
        else if (s.entry) setLog(l => [...l, s.entry]);
      }, acc);
    });
  };

  return (
    <div className={cx(
      "drawer-anim border-t flex-shrink-0",
      "bg-slate-950/95 border-slate-800",
      "[html:not(.dark)_&]:bg-slate-50 [html:not(.dark)_&]:border-slate-200",
      open ? "h-[340px]" : "h-[44px]"
    )}>
      {/* Header */}
      <div className="h-[44px] px-3 flex items-center gap-3 border-b border-slate-800/80 [html:not(.dark)_&]:border-slate-200 flex-shrink-0">
        <button onClick={onToggle} className="flex items-center gap-2 text-slate-200 hover:text-white [html:not(.dark)_&]:text-slate-700 [html:not(.dark)_&]:hover:text-slate-900">
          {open ? <I.ChevronDown size={15}/> : <I.ChevronUp size={15}/>}
          <span className="text-[12.5px] font-semibold tracking-tight">Claude Code</span>
        </button>

        <div className="flex items-center gap-1.5 px-2 h-6 rounded-md border border-emerald-500/30 bg-emerald-500/5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"/>
          <span className="font-mono text-[10.5px] text-emerald-300 [html:not(.dark)_&]:text-emerald-700">localhost:8765</span>
        </div>
        <span className="font-mono text-[10.5px] text-slate-500 hidden md:inline">
          session <span className="text-slate-300 [html:not(.dark)_&]:text-slate-700">4a2c8f</span>
          <span className="mx-1.5 text-slate-700">·</span>
          cwd <span className="text-slate-300 [html:not(.dark)_&]:text-slate-700">~/spark/order-platform</span>
        </span>

        <div className="flex-1"/>

        {open && (
          <div className="flex items-center gap-1.5">
            <span className="hidden sm:inline-flex items-center gap-1.5 h-6 px-2 rounded-md border border-slate-700 font-mono text-[10.5px] text-slate-300
              [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:text-slate-600">
              <I.Sparkles size={10} className="text-amber-400"/> {model}
            </span>
            <Btn variant="ghost" icon={I.History}>Sessions</Btn>
            <Btn variant="ghost" onClick={() => setLog([])}>Clear</Btn>
          </div>
        )}
      </div>

      {open && (
        <div className="h-[calc(340px-44px)] grid grid-rows-[1fr_auto_auto]">
          {/* Log */}
          <div ref={scrollRef} className="overflow-y-auto px-4 py-3 space-y-2.5">
            {log.length === 0 && (
              <div className="text-center text-[12px] text-slate-500 py-8">
                Connected to local Claude Code. Ask in prose, or use <span className="font-mono text-slate-300">/</span> for commands.
              </div>
            )}
            {log.map((e, i) => {
              if (e.kind === "user") {
                return (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-6 h-6 rounded-md bg-slate-700/80 text-[10px] font-bold text-slate-200 inline-flex items-center justify-center flex-shrink-0
                      [html:not(.dark)_&]:bg-slate-200 [html:not(.dark)_&]:text-slate-700">YOU</div>
                    <div className="text-[13px] text-slate-100 [html:not(.dark)_&]:text-slate-900 leading-relaxed flex-1 min-w-0">{e.text}</div>
                  </div>
                );
              }
              if (e.kind === "text") {
                return (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-6 h-6 rounded-md bg-gradient-to-br from-amber-400 to-rose-500 text-[10px] font-bold text-white inline-flex items-center justify-center flex-shrink-0">
                      <I.Sparkles size={11}/>
                    </div>
                    <div className="text-[13px] text-slate-200 [html:not(.dark)_&]:text-slate-800 leading-relaxed flex-1 min-w-0"
                         dangerouslySetInnerHTML={{ __html: e.text.replace(/\*\*(.+?)\*\*/g, '<span class="font-mono text-[12px] px-1 py-0.5 rounded bg-slate-800 text-blue-300">$1</span>') }}/>
                  </div>
                );
              }
              if (e.kind === "tool") {
                return (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-6 h-6 inline-flex items-center justify-center flex-shrink-0 text-slate-500 font-mono text-[15px] leading-none">●</div>
                    <div className="flex-1 min-w-0">
                      <ToolCard entry={e}/>
                    </div>
                  </div>
                );
              }
              return null;
            })}
            {busy && (
              <div className="flex items-center gap-2.5 pt-1">
                <div className="w-6 h-6 inline-flex items-center justify-center flex-shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"/>
                </div>
                <span className="text-[11.5px] font-mono text-slate-400">claude is working…</span>
              </div>
            )}
          </div>

          {/* Example prompts */}
          <div className="flex gap-1.5 px-4 py-2 overflow-x-auto no-scrollbar border-t border-slate-800/60 [html:not(.dark)_&]:border-slate-200">
            {EXAMPLE_PROMPTS.map(p => (
              <button key={p.text} onClick={() => ask(p.text)}
                className={cx(
                  "h-7 pl-2 pr-2.5 rounded-md text-[11.5px] flex-shrink-0 inline-flex items-center gap-1.5 font-mono",
                  p.slash
                    ? "bg-violet-500/10 border border-violet-500/30 text-violet-200 hover:bg-violet-500/15"
                    : "bg-slate-800/60 border border-slate-700 text-slate-200 hover:bg-slate-700/80 hover:text-white [html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:text-slate-700 [html:not(.dark)_&]:hover:bg-slate-100"
                )}>
                <span className="opacity-60">{p.icon}</span>
                {p.text}
              </button>
            ))}
          </div>

          {/* Input bar */}
          <div className="px-3 py-2.5 border-t border-slate-800/80 [html:not(.dark)_&]:border-slate-200 flex-shrink-0">
            <div className={cx(
              "flex items-center gap-2 rounded-lg border px-2 py-1.5 transition-colors focus-within:border-blue-500",
              "bg-slate-900/80 border-slate-700",
              "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200"
            )}>
              <span className="font-mono text-[13px] text-emerald-400 select-none pl-0.5">›</span>
              <input
                value={val}
                onChange={(e) => setVal(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") ask(val); }}
                placeholder='Ask Claude Code, or type "/" for slash commands…'
                className="flex-1 bg-transparent outline-none text-[13px] text-slate-100 placeholder:text-slate-500 font-mono
                  [html:not(.dark)_&]:text-slate-900 [html:not(.dark)_&]:placeholder:text-slate-400"
              />
              <span className="hidden sm:inline-flex items-center gap-1 font-mono text-[10px] text-slate-500">
                <Kbd>↵</Kbd> send
                <span className="mx-0.5">·</span>
                <Kbd>⇧↵</Kbd> newline
              </span>
              <button
                onClick={() => ask(val)}
                disabled={!val.trim() || busy}
                className="h-7 w-7 inline-flex items-center justify-center rounded-md bg-blue-600 hover:bg-blue-500 text-white disabled:opacity-40 disabled:cursor-not-allowed"
                title="Send"
              >
                <I.Send size={13}/>
              </button>
            </div>
            <div className="flex items-center justify-between mt-1.5 px-1">
              <span className="font-mono text-[10px] text-slate-500">
                <span className="text-slate-400">srml-mcp</span> · <span className="text-slate-400">filesystem</span> · <span className="text-slate-400">bash</span>
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                <span className="text-slate-400">142k / 200k</span> tokens
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Canvas, SRMLPanel, QueryDrawer, EXAMPLE_PROMPTS });
