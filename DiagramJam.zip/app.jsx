/* global React, ReactDOM, I, cx, Btn, Badge, TopNavBar, CenteredToolbar, Canvas, SRMLPanel, QueryDrawer, CommandPalette, ToastStack, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor, TweakSlider */
const { useState, useEffect, useCallback, useMemo } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": true,
  "density": "regular",
  "showMinimap": true,
  "showBoundaries": true,
  "accent": "#3B82F6",
  "zoom": 1
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // theme management
  useEffect(() => {
    document.documentElement.classList.toggle("dark", t.dark);
  }, [t.dark]);

  // state
  const [tool, setTool] = useState("select");
  const [selectedId, setSelectedId] = useState("api-gateway");
  const [srmlOpen, setSrmlOpen] = useState(true);
  const [queryOpen, setQueryOpen] = useState(true);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [standard, setStandard] = useState("C4 Model");
  const [toasts, setToasts] = useState([]);

  const toast = useCallback((opts) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(ts => [...ts, { id, variant: "info", ...opts }]);
    setTimeout(() => setToasts(ts => ts.filter(t => t.id !== id)), 4500);
  }, []);
  const dismissToast = (id) => setToasts(ts => ts.filter(t => t.id !== id));

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e) => {
      const mod = e.metaKey || e.ctrlKey;
      // Don't interfere with text inputs
      const tag = (e.target.tagName || "").toLowerCase();
      const isInput = tag === "input" || tag === "textarea" || e.target.isContentEditable;

      if (mod && e.key.toLowerCase() === "k") {
        e.preventDefault(); setPaletteOpen(p => !p);
      } else if (mod && e.key.toLowerCase() === "i") {
        e.preventDefault(); setSrmlOpen(s => !s);
      } else if (mod && e.key === "/") {
        e.preventDefault(); setQueryOpen(q => !q);
      } else if (!isInput && !mod) {
        const t = ({ v: "select", h: "hand", r: "rect", o: "ellipse", d: "diamond", a: "arrow", l: "line", p: "draw", t: "text", i: "image", k: "link" })[e.key.toLowerCase()];
        if (t) { setTool(t); }
        if (e.key === "Escape") setSelectedId(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Toolbar actions
  const onImport = (kind) => toast({ variant: "info", title: `Importing ${kind}…`, body: "Parsing and reconciling with current SRML graph." });
  const onExport = (kind) => toast({ variant: "success", title: `Exported ${kind}`, body: "Saved to your Downloads folder." });
  const onValidate = () => {
    toast({
      variant: "warning",
      title: "Validation finished with warnings",
      body: "9 elements valid · 3 warnings · 0 errors",
    });
  };
  const onAskAI = () => setQueryOpen(true);
  const onChooseStandard = (s) => {
    setStandard(s);
    toast({ variant: "info", title: s ? `Switched to ${s}` : "Switched to free-form", body: s ? "Shape palette and validation rules updated." : undefined });
  };

  // Command palette commands
  const commands = useMemo(() => [
    { id: "import-dot",     label: "Import DOT…",                  group: "File",       icon: I.FolderIn, shortcut: "⌘O", run: () => onImport("DOT") },
    { id: "import-visio",   label: "Import Visio…",                group: "File",       icon: I.FileText,                run: () => onImport("Visio") },
    { id: "export-dot",     label: "Export as .dot",               group: "File",       icon: I.FileText,                run: () => onExport("DOT") },
    { id: "export-svg",     label: "Export as SVG",                group: "File",       icon: I.Vector,   shortcut: "⌘E", run: () => onExport("SVG") },
    { id: "export-png",     label: "Export as PNG",                group: "File",       icon: I.Picture,                 run: () => onExport("PNG") },
    { id: "validate",       label: "Validate diagram",             group: "Diagram",    icon: I.Check,    shortcut: "⌘V", run: onValidate },
    { id: "ask-ai",         label: "Ask AI about this diagram",    group: "Diagram",    icon: I.Sparkles, shortcut: "⌘/", run: onAskAI },
    { id: "toggle-srml",    label: "Toggle SRML Inspector",        group: "View",       icon: I.Panel,    shortcut: "⌘I", run: () => setSrmlOpen(s => !s) },
    { id: "toggle-query",   label: "Toggle Claude Code panel",     group: "View",       icon: I.Sparkles, shortcut: "⌘/", run: () => setQueryOpen(q => !q) },
    { id: "toggle-theme",   label: t.dark ? "Switch to light mode" : "Switch to dark mode", group: "View", icon: t.dark ? I.Sun : I.Moon, run: () => setTweak("dark", !t.dark) },
    { id: "std-c4",         label: "Apply standard: C4 Model",     group: "Standards",  icon: I.Standards,               run: () => onChooseStandard("C4 Model") },
    { id: "std-uml",        label: "Apply standard: UML Class",    group: "Standards",  icon: I.Standards,               run: () => onChooseStandard("UML Class") },
    { id: "std-sysml",      label: "Apply standard: SysML IBD",    group: "Standards",  icon: I.Standards,               run: () => onChooseStandard("SysML IBD") },
    { id: "std-uaf",        label: "Apply standard: UAF SV-1",     group: "Standards",  icon: I.Standards,               run: () => onChooseStandard("UAF SV-1") },
    { id: "select-gateway", label: "Go to: API Gateway",           group: "Navigate",   hint: "component",               run: () => setSelectedId("api-gateway") },
    { id: "select-auth",    label: "Go to: AuthService",           group: "Navigate",   hint: "service",                 run: () => setSelectedId("auth") },
    { id: "select-orders",  label: "Go to: OrderService",          group: "Navigate",   hint: "service",                 run: () => setSelectedId("orders") },
    { id: "select-payments",label: "Go to: PaymentService",        group: "Navigate",   hint: "service",                 run: () => setSelectedId("payments") },
    { id: "select-db",      label: "Go to: Orders DB",             group: "Navigate",   hint: "datastore",               run: () => setSelectedId("db") },
  ], [t.dark]);

  const runCommand = (c) => c.run?.();

  return (
    <div className={cx(
      "h-screen flex flex-col overflow-hidden",
      "bg-slate-950 text-slate-100",
      "[html:not(.dark)_&]:bg-slate-50 [html:not(.dark)_&]:text-slate-900"
    )}>
      <TopNavBar
        dark={t.dark}
        srmlOpen={srmlOpen}
        onToggleTheme={() => setTweak("dark", !t.dark)}
        onToggleSRML={() => setSrmlOpen(s => !s)}
        onOpenCommand={() => setPaletteOpen(true)}
        onOpenHelp={() => toast({ variant: "info", title: "Help & shortcuts", body: "Press ⌘K to search commands. Press V/R/O/D/A to switch tools." })}
      />

      <CenteredToolbar
        tool={tool}
        setTool={setTool}
        onImport={onImport}
        onExport={onExport}
        onValidate={onValidate}
        onAskAI={onAskAI}
        currentStandard={standard}
        onChooseStandard={onChooseStandard}
      />

      <div className="flex-1 flex min-h-0">
        <Canvas
          selectedId={selectedId}
          setSelectedId={setSelectedId}
          dark={t.dark}
          zoom={t.zoom}
          tool={tool}
        />
        <SRMLPanel
          open={srmlOpen}
          onClose={() => setSrmlOpen(false)}
          selectedId={selectedId}
          onValidationToast={(kind) => toast({
            variant: kind === "saved" ? "success" : "info",
            title: kind === "saved" ? "Element saved" : "Changes discarded",
            body: kind === "saved" ? "SRML metadata committed to local cache." : undefined,
          })}
        />
      </div>

      <QueryDrawer
        open={queryOpen}
        onToggle={() => setQueryOpen(q => !q)}
        focusOnNodes={(nodes) => {
          if (nodes && nodes[0]) setSelectedId(nodes[0]);
          toast({ variant: "info", title: "Highlighted on canvas", body: `${nodes.length} element${nodes.length === 1 ? "" : "s"} focused.` });
        }}
      />

      <CommandPalette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        commands={commands}
        onRun={runCommand}
      />

      <ToastStack toasts={toasts} dismiss={dismissToast}/>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Appearance"/>
        <TweakToggle label="Dark mode"     value={t.dark}     onChange={(v) => setTweak("dark", v)}/>
        <TweakRadio  label="Density"       value={t.density}  options={["compact", "regular", "comfy"]} onChange={(v) => setTweak("density", v)}/>
        <TweakSection label="Canvas"/>
        <TweakSlider label="Zoom"          value={t.zoom}     min={0.6} max={1.4} step={0.05} unit="×" onChange={(v) => setTweak("zoom", v)}/>
        <TweakToggle label="Show minimap"  value={t.showMinimap}    onChange={(v) => setTweak("showMinimap", v)}/>
        <TweakToggle label="Show boundaries" value={t.showBoundaries} onChange={(v) => setTweak("showBoundaries", v)}/>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
