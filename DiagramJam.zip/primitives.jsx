/* global React, ReactDOM, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor, TweakSlider */
const { useState, useEffect, useMemo, useRef, useCallback, Fragment } = React;

/* ───────────────────────────────────────────────────────────────
   ICONS — minimal stroke set, lucide-style
   ─────────────────────────────────────────────────────────────── */
const Icon = ({ d, size = 16, className = "", strokeWidth = 1.7, fill = "none", children, viewBox = "0 0 24 24" }) => (
  <svg viewBox={viewBox} width={size} height={size} fill={fill} stroke="currentColor"
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className}>
    {d ? <path d={d} /> : children}
  </svg>
);

const I = {
  Help:        (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 015 0c0 1.4-2.5 1.9-2.5 3.5"/><circle cx="12" cy="17.2" r=".7" fill="currentColor" stroke="none"/></Icon>,
  Panel:       (p) => <Icon {...p}><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M14 4v16"/></Icon>,
  Command:     (p) => <Icon {...p}><path d="M8 6a2 2 0 1 1-2 2h12a2 2 0 1 1-2-2v12a2 2 0 1 1 2-2H6a2 2 0 1 1 2 2z"/></Icon>,
  Sparkles:    (p) => <Icon {...p}><path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6z"/><path d="M19 14l.7 1.8L21.5 16l-1.8.7L19 18.5l-.7-1.8L16.5 16l1.8-.7z"/></Icon>,
  ChevronDown: (p) => <Icon d="M6 9l6 6 6-6" {...p}/>,
  ChevronUp:   (p) => <Icon d="M6 15l6-6 6 6" {...p}/>,
  ChevronRight:(p) => <Icon d="M9 6l6 6-6 6" {...p}/>,
  X:           (p) => <Icon d="M18 6L6 18M6 6l12 12" {...p}/>,
  Search:      (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></Icon>,
  Send:        (p) => <Icon d="M22 2L11 13M22 2l-7 20-4-9-9-4z" {...p}/>,
  Check:       (p) => <Icon d="M20 6L9 17l-5-5" {...p}/>,
  Warn:        (p) => <Icon {...p}><path d="M10.3 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></Icon>,
  Info:        (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 8v.01M11 12h1v5h1"/></Icon>,
  History:     (p) => <Icon {...p}><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/></Icon>,

  // Tools
  Cursor:      (p) => <Icon d="M5 3l14 7-6 1.5L11 19z" {...p}/>,
  Hand:        (p) => <Icon {...p}><path d="M9 11V5a1.5 1.5 0 113 0v6"/><path d="M12 11V4a1.5 1.5 0 113 0v7"/><path d="M15 11V6a1.5 1.5 0 113 0v9a6 6 0 0 1-6 6 6 6 0 0 1-5-2.6L4 14a1.7 1.7 0 012.4-2.4L9 14V7a1.5 1.5 0 113 0"/></Icon>,
  Rect:        (p) => <Icon {...p}><rect x="4" y="5" width="16" height="14" rx="1.5"/></Icon>,
  Ellipse:     (p) => <Icon {...p}><ellipse cx="12" cy="12" rx="9" ry="6.5"/></Icon>,
  Diamond:     (p) => <Icon d="M12 3l9 9-9 9-9-9z" {...p}/>,
  Arrow:       (p) => <Icon d="M3 12h16M14 7l5 5-5 5" {...p}/>,
  Line:        (p) => <Icon d="M4 18L20 6" {...p}/>,
  Pencil:      (p) => <Icon d="M4 20l4-1 11-11a2.1 2.1 0 0 0-3-3L5 16l-1 4z" {...p}/>,
  Text:        (p) => <Icon d="M5 6h14M12 6v13M9 19h6" {...p}/>,
  Image:       (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M21 17l-5-5-9 9"/></Icon>,
  Link:        (p) => <Icon {...p}><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7L11.5 7"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7L12.5 17"/></Icon>,

  // Menus
  FolderIn:    (p) => <Icon {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v6M9 14l3 3 3-3"/></Icon>,
  FileText:    (p) => <Icon {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></Icon>,
  Code:        (p) => <Icon d="M16 18l6-6-6-6M8 6l-6 6 6 6" {...p}/>,
  Picture:     (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M21 17l-5-5-9 9"/></Icon>,
  Download:    (p) => <Icon d="M12 3v12M7 10l5 5 5-5M5 21h14" {...p}/>,
  Vector:      (p) => <Icon {...p}><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="15" width="6" height="6" rx="1"/><path d="M9 6h6a3 3 0 0 1 3 3v6"/></Icon>,
  Standards:   (p) => <Icon {...p}><path d="M4 4h16v6H4zM4 14h16v6H4z"/><path d="M7 7h2M7 17h2"/></Icon>,
  Shield:      (p) => <Icon d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z" {...p}/>,
  Sun:         (p) => <Icon {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/></Icon>,
  Moon:        (p) => <Icon d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z" {...p}/>,
};

/* ───────────────────────────────────────────────────────────────
   PRIMITIVES
   ─────────────────────────────────────────────────────────────── */

const cx = (...a) => a.filter(Boolean).join(" ");

function Kbd({ children, className = "" }) {
  return (
    <kbd className={cx(
      "inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded",
      "bg-slate-800/80 border border-slate-700 text-[10.5px] font-medium font-mono",
      "text-slate-300 tracking-tight",
      "dark:bg-slate-800/80 dark:border-slate-700 dark:text-slate-300",
      "[html:not(.dark)_&]:bg-slate-100 [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:text-slate-600",
      className
    )}>{children}</kbd>
  );
}

function IconBtn({ icon: Ic, title, onClick, active, size = "sm", className = "", children }) {
  const sz = size === "sm" ? "h-8 w-8" : "h-9 w-9";
  return (
    <button
      title={title}
      aria-label={title}
      onClick={onClick}
      className={cx(
        "inline-flex items-center justify-center rounded-md transition-colors",
        sz,
        active
          ? "bg-blue-600 text-white shadow-sm shadow-blue-900/40"
          : "text-slate-300 hover:text-white hover:bg-white/5 [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:text-slate-900 [html:not(.dark)_&]:hover:bg-slate-100",
        className
      )}
    >
      {Ic ? <Ic size={16}/> : children}
    </button>
  );
}

function Btn({ children, variant = "secondary", size = "sm", onClick, className = "", icon: Ic, disabled }) {
  const sizes = {
    sm: "h-8 px-2.5 text-[12.5px] gap-1.5",
    md: "h-9 px-3.5 text-sm gap-2",
  };
  const variants = {
    primary:   "bg-blue-600 hover:bg-blue-500 text-white shadow-sm shadow-blue-900/30",
    secondary: "bg-slate-800/80 hover:bg-slate-700/80 text-slate-100 border border-slate-700 [html:not(.dark)_&]:bg-white [html:not(.dark)_&]:hover:bg-slate-50 [html:not(.dark)_&]:text-slate-900 [html:not(.dark)_&]:border-slate-200",
    outline:   "border border-slate-700 text-slate-200 hover:bg-white/5 [html:not(.dark)_&]:border-slate-300 [html:not(.dark)_&]:text-slate-700 [html:not(.dark)_&]:hover:bg-slate-50",
    ghost:     "text-slate-300 hover:text-white hover:bg-white/5 [html:not(.dark)_&]:text-slate-600 [html:not(.dark)_&]:hover:text-slate-900 [html:not(.dark)_&]:hover:bg-slate-100",
    danger:    "bg-rose-600 hover:bg-rose-500 text-white",
  };
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={cx(
        "inline-flex items-center justify-center rounded-md font-medium transition-colors",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        sizes[size], variants[variant], className
      )}
    >
      {Ic && <Ic size={14}/>}
      {children}
    </button>
  );
}

function Badge({ children, variant = "default", className = "" }) {
  const v = {
    default: "bg-slate-800 text-slate-200 border-slate-700",
    success: "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
    warning: "bg-amber-500/10 text-amber-300 border-amber-500/30",
    error:   "bg-rose-500/10 text-rose-300 border-rose-500/30",
    info:    "bg-blue-500/10 text-blue-300 border-blue-500/30",
    outline: "border-slate-600 text-slate-300",
  }[variant];
  return (
    <span className={cx("inline-flex items-center gap-1 px-2 h-6 rounded-full text-[11px] font-medium border", v, className)}>
      {children}
    </span>
  );
}

/* Dropdown menu — controlled open + outside-click */
function Dropdown({ trigger, children, align = "left", width = 224 }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDoc); document.removeEventListener("keydown", onKey); };
  }, [open]);
  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className={cx(
          "inline-flex items-center gap-1.5 h-8 px-2.5 text-[12.5px] font-medium rounded-md transition-colors",
          open
            ? "bg-slate-800 text-white [html:not(.dark)_&]:bg-slate-100 [html:not(.dark)_&]:text-slate-900"
            : "text-slate-200 hover:bg-white/5 hover:text-white [html:not(.dark)_&]:text-slate-700 [html:not(.dark)_&]:hover:bg-slate-100 [html:not(.dark)_&]:hover:text-slate-900"
        )}
      >
        {trigger}
        <I.ChevronDown size={13} className="opacity-70"/>
      </button>
      {open && (
        <div
          style={{ width }}
          className={cx(
            "absolute z-40 mt-1.5 rounded-lg p-1 shadow-2xl shadow-black/40",
            "bg-slate-900/95 backdrop-blur border border-slate-700/80",
            "[html:not(.dark)_&]:bg-white [html:not(.dark)_&]:border-slate-200 [html:not(.dark)_&]:shadow-slate-300/50",
            align === "right" ? "right-0" : "left-0"
          )}
          onClick={() => setOpen(false)}
        >
          {children}
        </div>
      )}
    </div>
  );
}

function MenuItem({ icon: Ic, children, shortcut, onClick, danger }) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "w-full flex items-center gap-2.5 px-2 h-8 rounded-md text-[12.5px] transition-colors text-left",
        "text-slate-200 hover:bg-white/5 [html:not(.dark)_&]:text-slate-700 [html:not(.dark)_&]:hover:bg-slate-100",
        danger && "hover:bg-rose-500/10 hover:text-rose-300"
      )}
    >
      {Ic && <Ic size={14} className="text-slate-400 [html:not(.dark)_&]:text-slate-500"/>}
      <span className="flex-1">{children}</span>
      {shortcut && <Kbd>{shortcut}</Kbd>}
    </button>
  );
}

function MenuDivider() {
  return <div className="my-1 h-px bg-slate-700/60 [html:not(.dark)_&]:bg-slate-200"/>;
}

/* ───────────────────────────────────────────────────────────────
   SPARK WORDMARK — original abstract mark, not a real logo
   ─────────────────────────────────────────────────────────────── */
function SparkMark({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="sm-a" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3B82F6"/>
          <stop offset="1" stopColor="#1D4ED8"/>
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="28" height="28" rx="7" fill="url(#sm-a)"/>
      <path d="M16 7l3.2 5.6L25 14l-5.8 1.4L16 21l-3.2-5.6L7 14l5.8-1.4z" fill="#F8FAFC"/>
      <circle cx="22.5" cy="9.5" r="1.6" fill="#FBBF24"/>
    </svg>
  );
}

/* ───────────────────────────────────────────────────────────────
   SAMPLE DIAGRAM DATA
   ─────────────────────────────────────────────────────────────── */
const NODES = [
  { id: "client",       label: "Web Client",       x: 60,   y: 220, w: 150, h: 64, kind: "external",  shape: "rect" },
  { id: "mobile",       label: "Mobile Client",    x: 60,   y: 340, w: 150, h: 64, kind: "external",  shape: "rect" },
  { id: "api-gateway",  label: "API Gateway",      x: 290,  y: 280, w: 170, h: 70, kind: "component", shape: "rect",   selected: true, badge: "C4: container" },
  { id: "auth",         label: "AuthService",      x: 540,  y: 170, w: 160, h: 60, kind: "service",   shape: "rect" },
  { id: "orders",       label: "OrderService",     x: 540,  y: 280, w: 160, h: 60, kind: "service",   shape: "rect" },
  { id: "payments",     label: "PaymentService",   x: 540,  y: 390, w: 160, h: 60, kind: "service",   shape: "rect",   warn: true },
  { id: "queue",        label: "Event Bus",        x: 770,  y: 335, w: 130, h: 70, kind: "infra",     shape: "diamond" },
  { id: "db",           label: "Orders DB",        x: 970,  y: 220, w: 160, h: 70, kind: "datastore", shape: "ellipse" },
  { id: "audit",        label: "Audit Log",        x: 970,  y: 380, w: 160, h: 60, kind: "datastore", shape: "ellipse" },
];

const EDGES = [
  { from: "client",     to: "api-gateway", label: "HTTPS" },
  { from: "mobile",     to: "api-gateway", label: "HTTPS" },
  { from: "api-gateway",to: "auth",        label: "OAuth" },
  { from: "api-gateway",to: "orders" },
  { from: "api-gateway",to: "payments" },
  { from: "orders",     to: "db",          label: "SQL" },
  { from: "auth",       to: "db" },
  { from: "orders",     to: "queue",       label: "OrderPlaced" },
  { from: "payments",   to: "queue",       label: "PaymentDone" },
  { from: "queue",      to: "audit" },
];

/* Element-detail registry (SRML) — keyed by node id */
const ELEMENT_DATA = {
  "api-gateway": {
    id: "api-gateway",
    name: "API Gateway",
    type: "Component",
    domain: "Edge",
    owner: "platform-team",
    description: "Single entry point for external traffic. Handles TLS termination, request routing, JWT validation via AuthService, and rate-limiting per tenant.",
    specs: [
      { k: "Protocol",        v: "HTTPS/2, gRPC" },
      { k: "Latency budget",  v: "≤ 35ms p99" },
      { k: "Throughput",      v: "12,000 req/s sustained" },
      { k: "Auth",            v: "OAuth 2.1, mTLS upstream" },
      { k: "Deployment",      v: "Kubernetes, 6 replicas" },
    ],
    reqs: [
      { id: "REQ-NFR-014", title: "Service must terminate TLS 1.3 at the edge", status: "satisfied" },
      { id: "REQ-NFR-021", title: "p99 latency ≤ 35ms under nominal load",     status: "satisfied" },
      { id: "REQ-SEC-002", title: "All inbound traffic must carry a valid JWT", status: "satisfied" },
      { id: "REQ-NFR-031", title: "Graceful degradation on AuthService outage", status: "partial" },
    ],
    qa: { passing: 18, warnings: 3, errors: 0,
      checks: [
        { t: "Edges typed",                  ok: true },
        { t: "All ports typed",              ok: true },
        { t: "Owner assigned",               ok: true },
        { t: "Capacity declared",            ok: true },
        { t: "Failure mode documented",      ok: false, note: "Missing fallback for AuthService timeout" },
        { t: "ADR linked",                   ok: false, note: "No ADR referenced (recommended)" },
        { t: "Backwards-compat note",        ok: false, note: "Breaking change without migration plan" },
      ],
    },
    trace: [
      { from: "REQ-NFR-021", to: "TEST-LAT-04",  via: "design"   },
      { from: "REQ-SEC-002", to: "TEST-AUTH-11", via: "design"   },
      { from: "ADR-0007",    to: "api-gateway",  via: "decision" },
    ],
  },
};

/* Build a fallback element record for unselected nodes */
function elementFor(id) {
  if (ELEMENT_DATA[id]) return ELEMENT_DATA[id];
  const n = NODES.find(x => x.id === id);
  if (!n) return null;
  return {
    id: n.id, name: n.label, type: n.kind.charAt(0).toUpperCase() + n.kind.slice(1),
    domain: "—", owner: "unassigned",
    description: "No description yet. Use the SRML inspector to add spec-grade metadata for this element.",
    specs: [{ k: "Type", v: n.kind }],
    reqs: [], qa: { passing: 0, warnings: 0, errors: 0, checks: [] }, trace: [],
  };
}

Object.assign(window, { I, Icon, cx, Kbd, IconBtn, Btn, Badge, Dropdown, MenuItem, MenuDivider, SparkMark, NODES, EDGES, elementFor });
